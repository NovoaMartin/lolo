package graphics;

import javafx.scene.Node;

public interface Renderable {
    Node getRender();
}
