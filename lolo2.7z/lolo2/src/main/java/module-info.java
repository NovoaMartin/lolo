module lolo2.lolo2 {
    requires javafx.controls;
    exports Utils;
}
